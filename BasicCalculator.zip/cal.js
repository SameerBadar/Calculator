var valuesAndOperators = storingAndDisplaying();
function storingAndDisplaying(){
    let digitsAddress = document.getElementsByName('digits');
    var valuesAndOperators = [];
    for(let i = 0;i<digitsAddress.length;i++){
        digitsAddress[i].addEventListener('click',function(){
       valuesAndOperators.push(digitsAddress[i].innerText);
        document.getElementById('display').innerText = valuesAndOperators.join(' ');
    })
}
return valuesAndOperators;
}
function result(){
   var operatorIndexes = [];
   let operatorCounts =0;
   if(valuesAndOperators.length >=0 && valuesAndOperators.length<=2){
    document.getElementById('display').innerText = 'Syntax Error';
    return;
   }
   
   for(let i = 0;i<valuesAndOperators.length;i++){
        if(valuesAndOperators[i] =='/' || valuesAndOperators[i] == '+' || valuesAndOperators[i] =='-' || valuesAndOperators[i] =='*'){
            operatorIndexes.push(i);
            operatorCounts++;
        }
    }
    if(operatorCounts>1){
        for(let i= 1;i<operatorIndexes.length;i++){
            const indexes = operatorIndexes[i];
            if (
                !(Number(valuesAndOperators[indexes - 1]) >= 0 && Number(valuesAndOperators[indexes - 1]) <= 9) || 
                !(Number(valuesAndOperators[indexes + 1]) >= 0 && Number(valuesAndOperators[indexes + 1]) <= 9)
            ) {
                document.getElementById('display').innerText = "Syntax Error";
                return;
            }
                  
        }
        let leftPart = parseInt(valuesAndOperators.slice(0,operatorIndexes[0]).join(''),10);
        let rightPart = parseInt(valuesAndOperators.slice(operatorIndexes[0]+1,operatorIndexes[1]).join(''),10);
    let result = 0;
    let op = valuesAndOperators[operatorIndexes[0]];
    if(op == '*'){
        result = leftPart * rightPart;
    }
    else if(op == '+'){
        result = leftPart + rightPart;
    }
    else if(op == '-'){
        result = leftPart - rightPart;
    }
    else if(op == '/'){
        result = leftPart / rightPart;
    }
    for(let i = 1;i<operatorIndexes.length;i++){
      //Works for last Operator
        if(i<operatorIndexes.length){
        rightPart=  parseInt(valuesAndOperators.slice(operatorIndexes[i]+1).join(''),10);
            op = valuesAndOperators[operatorIndexes[i]];
            if(op == '*'){
                result *= rightPart;
              }
            else if(op == '+'){
                result +=rightPart; 
            }
            else if(op == '-'){
                result -= rightPart;
            }
            else if(op == '/'){
                result /= rightPart;
            }
    //Will display For Both Conditions
            document.getElementById('display').innerText = result;
            document.getElementById('display').style.fontSize='25px';
    
        }
    else{
        //Works for all the middle operators except first and last Operator
        rightPart = parseInt(valuesAndOperators.slice(indexes[i]+1,indexes[i+1]),10);
        if(indexes[i+1] == '*'){
            result *= rightPart;
          //  document.getElementById('display').innerText = result;
        }
        else if(indexes[i+1] == '+'){
            result += rightPart;
      //  document.getElementById('display').innerText = result;
        }
        else if(indexes[i+1] =='-'){
            result -= rightPart;
        //    document.getElementById('display').innerText = result;
        }
        else if(indexes[i+1] == '/'){
            result /= rightPart;
            document.getElementById('display').innerText = result;
            document.getElementById('display').style.fontSize='25px';
   
        }
        
    }
    }    
}
else {
    //Works for a single Operator
    const leftPart = parseInt(valuesAndOperators.slice(0,operatorIndexes[0]).join(''),10);
    const rightPart = parseInt(valuesAndOperators.slice(operatorIndexes[0]+1).join(''),10);
    let result = 0;
let op = valuesAndOperators[operatorIndexes[0]];
if(op == '*'){
    result = leftPart * rightPart;
    document.getElementById('display').innerText = result;
    document.getElementById('display').style.fontSize='25px';
   
    return;
}
else if(op == '+'){
    result = leftPart + rightPart;
    document.getElementById('display').innerText = result;
    document.getElementById('display').style.fontSize='25px';
   
    return;

}
else if(op == '-'){
    result = leftPart - rightPart;
    document.getElementById('display').innerText = result;
    document.getElementById('display').style.fontSize='25px';
   
    return;

}
else if(op == '/'){
    result = leftPart / rightPart;
    document.getElementById('display').innerText = result;
    document.getElementById('display').style.fontSize='25px';
   
    return;

}  
}
}

